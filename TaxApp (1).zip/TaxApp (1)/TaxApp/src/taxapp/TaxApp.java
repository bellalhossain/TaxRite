/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taxapp;

import java.io.Serializable;

/**
 *
 * @author x18114245
 */
public class TaxApp implements Serializable{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
       
        welcomeGUI GUI1 =new welcomeGUI();
        GUI1.setVisible(true);
        
        
        
        
    }
    
}
